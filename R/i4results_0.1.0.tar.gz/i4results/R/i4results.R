i4results <- function(original_model,
                      robustness_models,
                      out = NULL,
                      append = FALSE) {
  # 0) Prelim checks
  # Make sure openxlsx is installed if we want to export
  if (!is.null(out) && !requireNamespace("openxlsx", quietly = TRUE)) {
    stop("Package 'openxlsx' needed for Excel import/export. Please install it.")
  }

  # Enforce up to 5 robustness models
  if (length(robustness_models) > 5) {
    stop("You can supply up to 5 robustness models only.")
  }

  # 1) Process the original estimation
  o_cmdline <- paste(deparse(original_model$call), collapse = " ")
  o_n       <- stats::nobs(original_model)

  summary_o <- summary(original_model)
  coefs_o   <- as.data.frame(summary_o$coefficients)
  coefs_o   <- coefs_o[!(rownames(coefs_o) %in% "(Intercept)"), , drop = FALSE]

  ci_o      <- confint(original_model, level = 0.95)
  ci_o      <- as.data.frame(ci_o)
  colnames(ci_o) <- c("lower", "upper")
  ci_o      <- ci_o[!(rownames(ci_o) %in% "(Intercept)"), , drop = FALSE]

  paramlist_all <- rownames(coefs_o)

  # 2) Initialize results
  results_list <- list()

  # 3) Loop over each robustness estimation
  for (rep_name in names(robustness_models)) {
    rep_model  <- robustness_models[[rep_name]]
    r_cmdline  <- paste(deparse(rep_model$call), collapse = " ")
    r_n        <- stats::nobs(rep_model)

    summary_r  <- summary(rep_model)
    coefs_r    <- as.data.frame(summary_r$coefficients)
    coefs_r    <- coefs_r[!(rownames(coefs_r) %in% "(Intercept)"), , drop = FALSE]

    ci_r       <- confint(rep_model, level = 0.95)
    ci_r       <- as.data.frame(ci_r)
    colnames(ci_r) <- c("lower", "upper")
    ci_r       <- ci_r[!(rownames(ci_r) %in% "(Intercept)"), , drop = FALSE]

    for (p in paramlist_all) {
      # Original stats for p
      o_coeff    <- coefs_o[p, "Estimate"]
      o_std_err  <- coefs_o[p, "Std. Error"]
      o_t        <- coefs_o[p, "t value"]
      o_p_val    <- coefs_o[p, "Pr(>|t|)"]
      o_ci_lower <- ci_o[p, "lower"]
      o_ci_upper <- ci_o[p, "upper"]

      # Check if p is in the robustness model
      if (p %in% rownames(coefs_r)) {
        r_coeff    <- coefs_r[p, "Estimate"]
        r_std_err  <- coefs_r[p, "Std. Error"]
        r_t        <- coefs_r[p, "t value"]
        r_p_val    <- coefs_r[p, "Pr(>|t|)"]
        r_ci_lower <- ci_r[p, "lower"]
        r_ci_upper <- ci_r[p, "upper"]
      } else {
        r_coeff    <- NA
        r_std_err  <- NA
        r_t        <- NA
        r_p_val    <- NA
        r_ci_lower <- NA
        r_ci_upper <- NA
      }

      record <- data.frame(
        paramname  = p,
        study      = rep_name,

        o_cmdline  = substring(o_cmdline, 1, 244),  # up to 244 chars
        r_cmdline  = substring(r_cmdline, 1, 244),

        o_n        = o_n,
        r_n        = r_n,

        o_coeff    = round(o_coeff, 3),
        o_std_err  = round(o_std_err, 3),
        o_t        = round(o_t, 3),
        o_p_val    = round(o_p_val, 3),
        o_ci_lower = round(o_ci_lower, 3),
        o_ci_upper = round(o_ci_upper, 3),

        r_coeff    = round(r_coeff, 3),
        r_std_err  = round(r_std_err, 3),
        r_t        = round(r_t, 3),
        r_p_val    = round(r_p_val, 3),
        r_ci_lower = round(r_ci_lower, 3),
        r_ci_upper = round(r_ci_upper, 3),

        stringsAsFactors = FALSE
      )

      results_list[[length(results_list) + 1]] <- record
    }
  }

  # Combine into a single data frame
  results_df <- do.call(rbind, results_list)

  # 4) If out is provided, possibly append
  if (!is.null(out)) {
    if (append && file.exists(out)) {
      # read old file
      oldres <- openxlsx::read.xlsx(out)
      # combine
      combined <- rbind(oldres, results_df)
      # overwrite
      openxlsx::write.xlsx(combined, file = out, asTable = FALSE)
      message(paste("Appended results to Excel file:", out))
    } else {
      # overwrite or create
      openxlsx::write.xlsx(results_df, file = out, asTable = FALSE)
      if (append) {
        message(paste("File did not exist, so created a new Excel file:", out))
      } else {
        message(paste("Exported results to Excel file:", out))
      }
    }
  } else {
    message("Data with original & robustness comparisons returned as a data frame.")
  }

  invisible(results_df)
}
